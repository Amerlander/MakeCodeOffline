# WINDOWS
- 'Calliope MakeCode Windows.exe" per Doppelklick �ffnen, um MakeCode zu starten


# LINUX
- 'Start_Linux.sh' ausf�hrbar machen
- 'pxt/inc/node-linux' ausf�hrbar machen
- 'Start_Linux.sh' ausf�hren, um MakeCode zu starten


# OSX
- 'Start_macOS.sh' ausf�hrbar machen
- 'pxt/inc/node-macos' ausf�hrbar machen
- 'Start_macOS.sh' ausf�hren, um MakeCode zu starten