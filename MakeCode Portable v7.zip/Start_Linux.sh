#!/bin/bash
cd pxt/MakeCode
../inc/node-linux ../inc/yarn.js start

#netstat -na | grep "3232.*0.0.0.0:0"  >nul

#if ERRORLEVEL 1 (
#    cd pxt/MakeCode
#    nohub ../inc/node-linux ../inc/yarn.js start
#) else (
#    xdg-open "http://localhost:3232"
#)
#exit
